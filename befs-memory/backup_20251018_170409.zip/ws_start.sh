#!/usr/bin/env bash
open -a "Windsurf" --args --mode chat "/Users/daewookjeong/federation/studio"
# 로드시 약간의 여유 (필요시 늘리세요)
sleep 2
osascript "/Users/daewookjeong/windsurf-memory/launch_windsurf_and_startend.applescript"
