#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Append a session summary to ~/windsurf-memory/session-notes.md
and optionally trigger a backup via backup.sh

Usage:
  python3 memory_auto_logger.py --summary "오늘 한 일 3–5줄" [--backup]
  python3 memory_auto_logger.py --from-file /path/to/summary.txt [--backup]
  python3 memory_auto_logger.py --stdin [--backup]

This is Lv2 of BEFS Hybrid Memory.
"""
import os, sys, argparse, subprocess, datetime

def resolve_base():
    home = os.path.expanduser("~")
    base = os.path.join(home, "windsurf-memory")
    os.makedirs(base, exist_ok=True)
    return base

def append_summary(text):
    base = resolve_base()
    path = os.path.join(base, "session-notes.md")
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    block = f"\n\n## {ts}\n{text.strip()}\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(block)
    return path

def run_backup():
    base = resolve_base()
    backup = os.path.join(base, "backup.sh")
    if not os.path.exists(backup):
        print("backup.sh not found; skipping")
        return 0
    res = subprocess.run(["/bin/bash", backup], capture_output=True, text=True)
    print(res.stdout)
    if res.returncode != 0:
        print(res.stderr, file=sys.stderr)
    return res.returncode

def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--summary", help="Summary text (3–5 lines)")
    g.add_argument("--from-file", dest="from_file", help="Read summary from a file")
    g.add_argument("--stdin", action="store_true", help="Read summary from STDIN")
    ap.add_argument("--backup", action="store_true", help="Run backup after logging")
    args = ap.parse_args()

    if args.summary:
        text = args.summary
    elif args.from_file:
        with open(args.from_file, "r", encoding="utf-8") as f:
            text = f.read()
    else:
        text = sys.stdin.read()

    path = append_summary(text)
    print(f"Appended summary to: {path}")
    if args.backup:
        run_backup()

if __name__ == "__main__":
    main()
