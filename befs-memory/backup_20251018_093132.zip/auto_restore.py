#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lv3: Auto-restore last session summary at session start.
- Prints the most recent summary block from ~/windsurf-memory/session-notes.md
- Optional: --as-prompt prints a compact prompt suitable for system message.
"""
import os, sys, re, argparse, datetime

def read_last_summary(path):
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    # Blocks start with "## YYYY-MM-DD HH:MM"
    blocks = re.split(r"\n(?=## \d{4}-\d{2}-\d{2} \d{2}:\d{2})", text.strip())
    if not blocks:
        return None
    last = blocks[-1].strip()
    return last

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--as-prompt", action="store_true", help="Emit compact system prompt form")
    args = ap.parse_args()

    base = os.path.expanduser("~/windsurf-memory")
    notes = os.path.join(base, "session-notes.md")

    last = read_last_summary(notes)
    if not last:
        print("No previous session summary found.")
        sys.exit(0)

    if args.as_prompt:
        # Collapse lines and prefix with tag
        lines = [ln.strip() for ln in last.splitlines() if ln.strip()]
        content = " ".join(lines[1:]) if lines and lines[0].startswith("## ") else " ".join(lines)  # drop heading
        print(f"[RESTORE] Previous session summary → {content}")
    else:
        print(last)

if __name__ == "__main__":
    main()
